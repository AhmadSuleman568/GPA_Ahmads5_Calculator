package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText[] gradeEditTexts = new EditText[5];
    private Button computeButton;
    private TextView gpaResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        gradeEditTexts[0] = findViewById(R.id.editTextTextPersonName);
        gradeEditTexts[1] = findViewById(R.id.editTextTextPersonName2);
        gradeEditTexts[2] = findViewById(R.id.editTextTextPersonName3);
        gradeEditTexts[3] = findViewById(R.id.editTextTextPersonName4);
        gradeEditTexts[4] = findViewById(R.id.editTextTextPersonName5);
        computeButton = findViewById(R.id.button2);
        gpaResult = findViewById(R.id.textView6);
        computeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (computeButton.getText().equals("Clear Form")) {
                    clearForm();
                    computeButton.setText("Compute GPA");
                }
                else {
                    computeGPA();
                }
            }
        });
    }


                private void computeGPA() {
                // Calculate GPA and display it
                double totalGrade = 0;
                int validFields = 0;
                for (EditText editText : gradeEditTexts) {
                    if (!editText.getText().toString().isEmpty()) {
                        totalGrade += Double.parseDouble(editText.getText().toString());
                        validFields++;
                    }
                }

                if (validFields == 0) {
                    gpaResult.setText("Please enter grades for at least one course.");
                    return;
                }

                double gpa = totalGrade / validFields;

                gpaResult.setText(String.format("GPA: %.2f", gpa));

                // Change button text and set background color based on GPA
                computeButton.setText("Clear Form");
                if (gpa < 60) {
                    gpaResult.setBackgroundColor(Color.RED);
                } else if (gpa >= 60 && gpa <= 79) {
                    gpaResult.setBackgroundColor(Color.YELLOW);
                } else {
                    gpaResult.setBackgroundColor(Color.GREEN);
                }
            }

    private void clearForm() {
        gradeEditTexts[0].setText("");
        gradeEditTexts[1].setText("");
        gradeEditTexts[2].setText("");
        gradeEditTexts[3].setText("");
        gradeEditTexts[4].setText("");
        gpaResult.setText("");
    }
     }

